package com.greatlearning.labsession5.service;

import java.util.List;

import com.greatlearning.labsession5.entity.StudentDetail;

public interface StudentService {

	 List<StudentDetail> findAll();

	void save(StudentDetail S);

	void delete(StudentDetail S);

	List<StudentDetail> findBycountry(String country);
	
	public StudentDetail findById(Integer id);

}
