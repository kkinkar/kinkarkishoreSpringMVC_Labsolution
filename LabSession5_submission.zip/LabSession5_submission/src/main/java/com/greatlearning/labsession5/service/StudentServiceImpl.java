package com.greatlearning.labsession5.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.greatlearning.labsession5.entity.StudentDetail;


@Repository

public class StudentServiceImpl implements StudentService {
	
	private SessionFactory sessionFactory;
	
	private Session session;

	public StudentServiceImpl(SessionFactory sessionfactory) {
		this.sessionFactory = sessionfactory;		
		try {
			session=this.sessionFactory.getCurrentSession();
			
		} catch (HibernateException e) {
			session=this.sessionFactory.openSession();
		}
	}
	
	@Transactional
	@Override
	public List<StudentDetail> findBycountry(String country) {
		List<StudentDetail> studentList=null;
		String query="";
		
		if(country.length()!=0)
			query="from StudentDetail where country like '%"+country+"%'";
		else
			query="from StudentDetail";
		if(query.length()!=0)
		{
			studentList=session.createQuery(query).list();
		}
		return studentList;
	}
	
	@Transactional
	public List <StudentDetail> findAll(){
		List<StudentDetail> studentList=session.createQuery("from StudentDetail").list();
		for(StudentDetail b:studentList)
		{
			System.out.println(b);
		}
		return studentList;	
	}
	@Transactional
	public void save (StudentDetail S) {
		Transaction tr=session.beginTransaction();
		session.saveOrUpdate(S);
		tr.commit();
		
	}
	@Transactional
	public void delete(StudentDetail S) {
		Transaction tr=session.beginTransaction();
		session.delete(S);
		tr.commit();
		
	}
	@Transactional
	public StudentDetail findById(Integer id) {
		StudentDetail sd=session.get(StudentDetail.class, id);		
		return sd;
		
	}
	

}
