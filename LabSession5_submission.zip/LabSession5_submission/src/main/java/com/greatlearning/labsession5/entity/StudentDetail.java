package com.greatlearning.labsession5.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="detail")
public class StudentDetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//3. these instance variables should match
	private int id;
	private String f_name;
	private String l_name;
	private String country;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public StudentDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDetail(String f_name, String l_name, String country) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.country = country;
	}
	@Override
	public String toString() {
		return "StudentDetail [id=" + id + ", f_name=" + f_name + ", l_name=" + l_name + ", country=" + country + "]";
	}

	
}
