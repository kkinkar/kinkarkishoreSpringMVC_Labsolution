package com.greatlearning.labsession5.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.labsession5.entity.StudentDetail;
import com.greatlearning.labsession5.service.StudentService;



@Controller
@RequestMapping("/Students")

public class StudentController {
	
	@Autowired
	public StudentService studentService;
		
		@RequestMapping("/list")
		public String findAll(Model model)
		{
			List<StudentDetail> studentList=studentService.findAll() ;
			model.addAttribute("studentList", studentList);//2. this studentList and
			return "Student";//This and the JSP file name should match
		}
		
		@RequestMapping("/save")
		public String save(@RequestParam("id") Integer id,@RequestParam("f_name") String f_name,@RequestParam("l_name") String l_name,
				@RequestParam("country") String country) {
		
			System.out.println("Id:: "+id);
			System.out.println("First name:: "+f_name);
			System.out.println("Last name:: "+l_name);
			System.out.println("Country:: "+country);
			
			StudentDetail student = null;
			if (id!=0) {
				student=studentService.findById(id);
				student.setCountry(country);
				student.setF_name(f_name);
				student.setL_name(l_name);
			}
			else 
				student=new StudentDetail(f_name, l_name, country);
			
			studentService.save(student);
			return "redirect:list";
		}
		
		@RequestMapping("/addStudent")
		public String addStudent(@RequestParam("id") Integer id, Model model)
		{
		System.out.println("Id: "+id);
			
			if(id!=0)
			{
				StudentDetail S=studentService.findById(id);
				model.addAttribute("student", S);
			}
			else
			{
				StudentDetail S=new StudentDetail();
				S.setId(0);
				model.addAttribute("student", S);//1. this and 
			}
			
			return "studentForm";
		}
		
		@RequestMapping("/deleteStudent")
		public String delete(@RequestParam("id") Integer id)
		{
			StudentDetail S=null;
			if(id!=-1)
			{
				S=studentService.findById(id);
				studentService.delete(S);
			}
			
			return "redirect:list";
		}
		
		@RequestMapping("/search")
		public String findBycountry(@RequestParam("country")String country,Model model)
		{
			List<StudentDetail> studentList=studentService.findBycountry(country) ;
			System.out.println(studentList);
			if(studentList.size()!=0)
				model.addAttribute("student", studentList);
			else
				model.addAttribute("error", "No record Found");
			return  "redirect:list";
		}
		
	}